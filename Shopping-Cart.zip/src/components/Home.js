import React, { Component } from 'react';
import { connect } from 'react-redux'
import { addToCart } from './actions/cartActions'

 class Home extends Component{
    
    handleClick = (id)=>{
        this.props.addToCart(id); 
    }

    render(){
        let itemList = this.props.items.map(item=>{
            return(
                <div className="card mr-2"
                
            key={item.id}>
                        <div className="card-image
                    img-fluid m-4 object-cover
                        ">
                            <img src={item.img} alt={item.title}
                            className="bg-gray-100"
                            />
                        </div>

                        <div className="card-content">
                        <span className="text-2xl font-normal">{item.title}</span>
                            <p>{item.desc}</p>
                            <p><b>Price: Rs.{item.price}  </b>
                            <span
                            className="line-through
                            text-gray-400
                            "
                            >   Rs. 300</span>
                            </p>
                           
                            <div
                        className="text-center mt-2"
                        >
                        <button className="btn bg-blue-700
                        
                        " onClick={()=>{this.handleClick(item.id)}}>ADD TO CART</button>
                        </div>
                        </div>
                 </div>

            )
        })

        return(
            <div className="container">
                <h3 className="center text-4xl font-bold mt-4 mb-4
                
                ">Our items</h3>
                <div className="box">
                    {itemList}
                </div>
            </div>
        )
    }
}
const mapStateToProps = (state)=>{
    return {
      items: state.items
    }
  }
const mapDispatchToProps= (dispatch)=>{
    
    return{
        addToCart: (id)=>{dispatch(addToCart(id))}
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(Home)