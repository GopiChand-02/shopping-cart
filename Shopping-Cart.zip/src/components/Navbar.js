import React from 'react';
import { Link } from 'react-router-dom'
 const Navbar = ()=>{

    const cStyle = {
        backgroundColor: '#1565C0',
    }

    return(
            <nav className="nav-wrapper sticky top-0 z-50
            " style={cStyle}>
                <div>

                    <div
                    className="
                    text-center
                    "
                    >
                    <Link to="/" className="brand-logo">Shopping Cart</Link>
                    </div>

                    <ul className="right">
                        <li><Link to="/cart"><i className="material-icons">shopping_cart</i></Link></li>
                    </ul>
                </div>
            </nav>
   
        
    )
}

export default Navbar;